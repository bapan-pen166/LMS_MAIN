from meeting_id import generate_meeting_id, generate_passcode

id = generate_meeting_id()
passcode = generate_passcode()

print(f"Meeting ID: {id}")
print(f"Passcode: {passcode}")